package com.sohel.assetmanager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AssetmanagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(AssetmanagerApplication.class, args);
	}

}
